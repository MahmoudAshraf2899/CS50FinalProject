# Notes Web Application

#### Video Demo: https://www.youtube.com/watch?v=GA-k470V7J0

#### Description:

# Project Title

Notes Web Application

# CS50

This was my final project for conclude the CS50 Introduction to Computer Sciense course.

CS, python, flask, flask web framework, web development, CS50

# Features

Flask-SQLAlchemy

flask_login

werkzeug.security

I've used Flask web framework based in Python its was necessary flask-sqlalchemy for manage SQL database with sqlite and flask-login for handle user authorization and authentications

# Explaining the project and the database

This Project is Web Application By Using Python & SQL & Java script and Flask .Users Can Create Accounts and Sign in to add their daily Notes and they have option to delete any of them as they want this project have alot of validations on sign-up page and login page
We have two tables in our database (user,notes) with one to many relationship
one user can have alot of notes
in sign-in page and login page we have alot of validation you can see them in auth.py file

## Usage/Examples

```javascript
user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists.', category='error')
        elif len(email) < 4:
            flash('Email must be greater than 3 characters.', category='error')
        elif len(first_name) < 2:
            flash('First name must be greater than 1 character.', category='error')
        elif password1 != password2:
            flash('Passwords don\'t match.', category='error')
        elif len(password1) < 7:
            flash('Password must be at least 7 characters.', category='error')
        else:
            new_user = User(email=email, first_name=first_name, password=generate_password_hash(
                password1, method='sha256'))
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember=True)
            flash('Account created!', category='success')
            return redirect(url_for('views.home'))
```

## Screenshots

[Email Validation](https://drive.google.com/file/d/1ipgpZknswdoPSUjsxJsMN_irRzxZ3URY/view)
|
[Password Validation](https://drive.google.com/file/d/1OtRkK2JEAVqTHyA7hzU9g9dJrQbfo_gJ/view?usp=sharing)
|
[Login Success](https://drive.google.com/file/d/1X3Yu0XEjcjbGE9Puk6l9SrTQR-ercl_B/view?usp=sharing)
|
[Sign-Up Validation](https://drive.google.com/file/d/176MX0iFI6Iffu6OvrTWSmOZre0j9HhlI/view?usp=share_link)

## Resources

https://flask.palletsprojects.com/en/1.1.x/

https://flask-sqlalchemy.palletsprojects.com/en/2.x/

https://flask-login.readthedocs.io/en/latest/

## About CS50

CS50 is a openware course from Havard University and taught by David J. Malan

Introduction to the intellectual enterprises of computer science and the art of programming. This course teaches students how to think algorithmically and solve problems efficiently. Topics include abstraction, algorithms, data structures, encapsulation, resource management, security, and software engineering. Languages include C, Python, and SQL plus students’ choice of: HTML, CSS, and JavaScript (for web development).

Thank you for all CS50.
